SELECT C.nume, C.prenume
FROM Client C
WHERE EXISTS (
    SELECT 1
    FROM Comanda Co
    JOIN Detalii_Comanda D ON Co.id_comanda = D.id_comanda
    JOIN Produs_Meniu P ON D.id_produs = P.id_produs
    JOIN Reteta R ON P.id_produs = R.id_produs
    JOIN Ingredient I ON R.id_ingredient = I.id_ingredient
    WHERE Co.id_client = C.id_client  -- Aici este corelarea cu tabelul principal
    AND I.nume_ingredient = 'Carne Vita'
);