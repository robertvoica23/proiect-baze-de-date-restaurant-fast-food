SELECT denumire_produs, pret
FROM Produs_Meniu
WHERE id_produs IN (
    SELECT DISTINCT D.id_produs
    FROM Detalii_Comanda D
    JOIN Comanda Co ON D.id_comanda = Co.id_comanda
    JOIN Plata P ON Co.id_comanda = P.id_comanda
    WHERE P.metoda_plata = 'Card'
);