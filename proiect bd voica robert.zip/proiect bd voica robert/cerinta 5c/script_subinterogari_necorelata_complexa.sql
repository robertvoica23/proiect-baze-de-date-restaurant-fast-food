SELECT denumire_produs
FROM Produs_Meniu
WHERE id_produs IN (
    SELECT id_produs
    FROM Reteta
    WHERE id_ingredient IN (
        SELECT id_ingredient
        FROM Ingredient
        WHERE stoc_curent < 10
    )
);