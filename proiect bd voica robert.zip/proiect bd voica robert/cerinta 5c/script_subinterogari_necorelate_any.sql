SELECT denumire_produs, pret
FROM Produs_Meniu
WHERE pret > ANY (
    SELECT pret 
    FROM Produs_Meniu 
    WHERE id_categorie = (
        SELECT id_categorie 
        FROM Categorie 
        WHERE denumire = 'Garnituri'
    )
);