-- 1. Interogarea (QUERY) pe care vrem sa o optimizam
-- Cautam un client specific dupa Nume si Prenume
SELECT * FROM Client 
WHERE nume = 'Popescu' 
  AND prenume = 'Ion';

-- 2. Crearea Indexului Compus (optimineaza cautarea cu 2 criterii)
CREATE INDEX idx_client_nume_prenume 
ON Client (nume, prenume);