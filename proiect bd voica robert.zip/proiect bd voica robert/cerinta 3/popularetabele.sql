-- Inserare CLIENTI
INSERT INTO Client (nume, prenume, telefon, email) VALUES
('Popescu', 'Ion', '0722111111', 'ion.popescu@email.com'),
('Ionescu', 'Maria', '0722222222', 'maria.ionescu@email.com'),
('Georgescu', 'Vlad', '0722333333', 'vlad.g@email.com'),
('Dumitru', 'Ana', '0722444444', 'ana.d@email.com'),
('Stancu', 'Radu', '0722555555', 'radu.stancu@email.com');

-- Inserare ANGAJATI
INSERT INTO Angajat (nume, prenume, functie) VALUES
('Vasilescu', 'Dan', 'Manager'),
('Marinescu', 'Elena', 'Casier'),
('Dobre', 'Cristi', 'Bucatar'),
('Nistor', 'Ioana', 'Casier'),
('Barbu', 'Alex', 'Bucatar');

-- Inserare CATEGORII
INSERT INTO Categorie (denumire) VALUES
('Burgeri'), ('Bauturi'), ('Garnituri'), ('Sosuri'), ('Desert');

-- Inserare INGREDIENTE
INSERT INTO Ingredient (nume_ingredient, stoc_curent, unitate_masura) VALUES
('Chifla', 100, 'buc'),
('Carne Vita', 20, 'kg'),
('Cartofi', 50, 'kg'),
('Suc Cola', 100, 'l'),
('Branza Cheddar', 10, 'kg');

-- Inserare PRODUSE
INSERT INTO Produs_Meniu (id_categorie, denumire_produs, pret, gramaj) VALUES
(1, 'Cheeseburger', 15.50, 250),
(1, 'Double Burger', 22.00, 400),
(2, 'Cola 0.5L', 6.00, 500),
(3, 'Cartofi Prajiti', 8.50, 150),
(5, 'Inghetata', 5.00, 100);

-- Inserare RETETA (Legaturi ingrediente cu produse)
INSERT INTO Reteta (id_produs, id_ingredient, cantitate_necesara) VALUES
(1, 1, 1), -- Cheeseburger cere 1 chifla
(1, 2, 0.150), -- Cheeseburger cere 150g carne
(1, 5, 0.050), -- Cheeseburger cere 50g branza
(3, 4, 0.5), -- Cola cere 0.5l suc
(4, 3, 0.200); -- Cartofi prajiti cer 200g cartofi

-- Inserare COMENZI
INSERT INTO Comanda (id_client, id_angajat, data_ora, status, tip) VALUES
(1, 2, '2023-10-01 12:00:00', 'Finalizat', 'In restaurant'),
(2, 2, '2023-10-01 12:15:00', 'Finalizat', 'La pachet'),
(3, 4, '2023-10-01 12:30:00', 'In procesare', 'In restaurant'),
(4, 4, '2023-10-01 13:00:00', 'Anulat', 'La pachet'),
(5, 2, '2023-10-01 13:10:00', 'In procesare', 'In restaurant');

-- Inserare DETALII COMANDA
INSERT INTO Detalii_Comanda (id_comanda, id_produs, cantitate, observatii) VALUES
(1, 1, 2, 'Fara ceapa'), -- Comanda 1: 2 Cheeseburgeri
(1, 3, 2, NULL),       -- Comanda 1: 2 Cola
(2, 2, 1, 'Bine facut'),
(3, 4, 3, 'Cu sare'),
(5, 5, 1, NULL);

-- Inserare PLATA
INSERT INTO Plata (id_comanda, suma, metoda_plata) VALUES
(1, 43.00, 'Card'),
(2, 22.00, 'Cash'),
(3, 25.50, 'Card'),
(4, 0.00, NULL), -- Comanda anulata
(5, 5.00, 'Cash');