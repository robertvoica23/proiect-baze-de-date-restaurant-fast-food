-- B.1. UPDATE: Modificam stocul pentru un ingredient (ex: am primit marfa)
UPDATE Ingredient
SET stoc_curent = stoc_curent + 50
WHERE nume_ingredient = 'Chifla';

-- B.2. UPDATE: Schimbam statusul unei comenzi
UPDATE Comanda
SET status = 'Finalizat'
WHERE id_comanda = 5;

-- B.3. DELETE: Stergem un client care nu ne intereseaza (atentie la FK, daca are comenzi va da eroare fara CASCADE)
-- Vom sterge un client fictiv inserat acum
INSERT INTO Client (nume, prenume) VALUES ('Test', 'Sters');
DELETE FROM Client WHERE nume = 'Test';