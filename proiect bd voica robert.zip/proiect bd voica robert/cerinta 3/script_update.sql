UPDATE Comanda
SET status = 'Paid & Confirmed'
WHERE id_comanda IN (
    SELECT id_comanda 
    FROM Plata 
    WHERE suma > 0
);