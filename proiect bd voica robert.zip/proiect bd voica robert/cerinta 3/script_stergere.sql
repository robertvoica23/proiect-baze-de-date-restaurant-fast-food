DELETE FROM Ingredient
WHERE id_ingredient NOT IN (
    SELECT DISTINCT id_ingredient 
    FROM Reteta
);