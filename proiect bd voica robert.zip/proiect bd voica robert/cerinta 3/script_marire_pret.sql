UPDATE Produs_Meniu
SET pret = pret * 1.10
WHERE id_categorie IN (
    SELECT id_categorie 
    FROM Categorie 
    WHERE denumire = 'Burgeri'
);