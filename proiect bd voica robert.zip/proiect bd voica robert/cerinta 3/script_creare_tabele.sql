-- Stergem tabelele vechi daca exista (pentru a putea rerula scriptul)
DROP TABLE IF EXISTS Plata CASCADE;
DROP TABLE IF EXISTS Detalii_Comanda CASCADE;
DROP TABLE IF EXISTS Reteta CASCADE;
DROP TABLE IF EXISTS Produs_Meniu CASCADE;
DROP TABLE IF EXISTS Comanda CASCADE;
DROP TABLE IF EXISTS Angajat CASCADE;
DROP TABLE IF EXISTS Categorie CASCADE;
DROP TABLE IF EXISTS Ingredient CASCADE;
DROP TABLE IF EXISTS Client CASCADE;

-- 1. Tabela CLIENT
CREATE TABLE Client (
    id_client SERIAL PRIMARY KEY,
    nume VARCHAR(50) NOT NULL,
    prenume VARCHAR(50) NOT NULL,
    telefon VARCHAR(15),
    email VARCHAR(100) UNIQUE
);

-- 2. Tabela ANGAJAT
CREATE TABLE Angajat (
    id_angajat SERIAL PRIMARY KEY,
    nume VARCHAR(50) NOT NULL,
    prenume VARCHAR(50) NOT NULL,
    functie VARCHAR(50) -- ex: Casier, Manager, Bucatar
);

-- 3. Tabela CATEGORIE (ex: Bauturi, Burgeri)
CREATE TABLE Categorie (
    id_categorie SERIAL PRIMARY KEY,
    denumire VARCHAR(50) NOT NULL
);

-- 4. Tabela INGREDIENT (Stocuri)
CREATE TABLE Ingredient (
    id_ingredient SERIAL PRIMARY KEY,
    nume_ingredient VARCHAR(50) NOT NULL,
    stoc_curent DECIMAL(10, 2) DEFAULT 0,
    unitate_masura VARCHAR(10) -- ex: kg, buc, l
);

-- 5. Tabela PRODUS_MENIU (Ce se vinde)
CREATE TABLE Produs_Meniu (
    id_produs SERIAL PRIMARY KEY,
    id_categorie INT REFERENCES Categorie(id_categorie),
    denumire_produs VARCHAR(100) NOT NULL,
    pret DECIMAL(10, 2) NOT NULL,
    gramaj INT
);

-- 6. Tabela RETETA (Legatura Produs - Ingredient)
CREATE TABLE Reteta (
    id_reteta SERIAL PRIMARY KEY,
    id_produs INT REFERENCES Produs_Meniu(id_produs) ON DELETE CASCADE,
    id_ingredient INT REFERENCES Ingredient(id_ingredient),
    cantitate_necesara DECIMAL(10, 3) -- cata materie prima se consuma
);

-- 7. Tabela COMANDA
CREATE TABLE Comanda (
    id_comanda SERIAL PRIMARY KEY,
    id_client INT REFERENCES Client(id_client),
    id_angajat INT REFERENCES Angajat(id_angajat),
    data_ora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'In procesare', -- In procesare, Finalizat, Anulat
    tip VARCHAR(20) -- La pachet, In restaurant
);

-- 8. Tabela DETALII_COMANDA (Ce contine comanda)
CREATE TABLE Detalii_Comanda (
    id_detaliu SERIAL PRIMARY KEY,
    id_comanda INT REFERENCES Comanda(id_comanda) ON DELETE CASCADE,
    id_produs INT REFERENCES Produs_Meniu(id_produs),
    cantitate INT NOT NULL,
    observatii VARCHAR(200) -- ex: Fara gheata
);

-- 9. Tabela PLATA
CREATE TABLE Plata (
    id_plata SERIAL PRIMARY KEY,
    id_comanda INT REFERENCES Comanda(id_comanda) UNIQUE, -- Relatie 1 la 1
    suma DECIMAL(10, 2) NOT NULL,
    metoda_plata VARCHAR(20), -- Cash, Card
    data_plata TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);