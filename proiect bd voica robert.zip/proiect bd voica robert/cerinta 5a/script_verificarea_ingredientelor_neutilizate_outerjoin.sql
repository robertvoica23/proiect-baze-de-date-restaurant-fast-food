SELECT 
    I.nume_ingredient,
    I.stoc_curent,
    R.id_reteta
FROM Ingredient I
FULL OUTER JOIN Reteta R ON I.id_ingredient = R.id_ingredient
WHERE I.id_ingredient IS NULL OR R.id_ingredient IS NULL;