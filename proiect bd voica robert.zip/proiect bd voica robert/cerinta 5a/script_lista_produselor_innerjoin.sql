SELECT 
    Cat.denumire AS Categorie,
    P.denumire_produs,
    D.cantitate,
    P.pret AS Pret_Unitar, 
    (D.cantitate * P.pret) AS Valoare_Totala_Linie -- Calculam totalul per produs
FROM Detalii_Comanda D
INNER JOIN Produs_Meniu P ON D.id_produs = P.id_produs
INNER JOIN Categorie Cat ON P.id_categorie = Cat.id_categorie;