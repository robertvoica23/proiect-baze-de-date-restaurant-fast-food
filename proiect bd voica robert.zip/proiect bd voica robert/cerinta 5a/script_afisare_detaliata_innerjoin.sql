SELECT 
    C.nume AS Nume_Client, 
    C.prenume AS Prenume_Client,
    Co.data_ora,
    Co.status,
    A.nume AS Nume_Angajat
FROM Comanda Co
INNER JOIN Client C ON Co.id_client = C.id_client
INNER JOIN Angajat A ON Co.id_angajat = A.id_angajat;