SELECT 
    C.nume, 
    C.prenume, 
    C.email
FROM Client C
LEFT JOIN Comanda Co ON C.id_client = Co.id_client
WHERE Co.id_comanda IS NULL;