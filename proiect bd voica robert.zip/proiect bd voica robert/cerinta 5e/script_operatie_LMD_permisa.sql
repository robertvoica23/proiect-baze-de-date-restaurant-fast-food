-- Creare vedere simpla (doar clientii cu email)
CREATE OR REPLACE VIEW V_Clienti_Contactabili AS
SELECT id_client, nume, prenume, email 
FROM Client 
WHERE email IS NOT NULL;

-- OPERATIE PERMISA: Insert prin vedere
-- Aceasta va insera de fapt in tabelul 'Client' din spate
INSERT INTO V_Clienti_Contactabili (nume, prenume, email) 
VALUES ('Teodorescu', 'Mihai', 'mihai.teo@email.com');

-- Verificare
SELECT * FROM Client WHERE nume = 'Teodorescu';