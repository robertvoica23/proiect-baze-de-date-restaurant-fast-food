CREATE OR REPLACE VIEW V_Meniu_Public AS
SELECT 
    C.denumire AS Categorie,
    P.denumire_produs AS Produs,
    P.pret,
    P.gramaj
FROM Produs_Meniu P
JOIN Categorie C ON P.id_categorie = C.id_categorie;