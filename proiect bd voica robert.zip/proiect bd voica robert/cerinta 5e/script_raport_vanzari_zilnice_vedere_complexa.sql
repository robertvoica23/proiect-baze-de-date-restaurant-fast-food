CREATE OR REPLACE VIEW V_Vanzari_Zilnice AS
SELECT 
    DATE(data_plata) AS Ziua,
    COUNT(id_plata) AS Nr_Tranzactii,
    SUM(suma) AS Total_Incasari
FROM Plata
GROUP BY DATE(data_plata);