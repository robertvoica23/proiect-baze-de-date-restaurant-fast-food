-- OPERATIE NEPERMISA
DELETE FROM V_Vanzari_Zilnice 
WHERE Total_Incasari < 100;