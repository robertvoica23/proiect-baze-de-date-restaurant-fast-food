CREATE OR REPLACE VIEW V_Comenzi_Bucatarie AS
SELECT 
    Co.id_comanda,
    P.denumire_produs,
    D.cantitate,
    D.observatii
FROM Comanda Co
JOIN Detalii_Comanda D ON Co.id_comanda = D.id_comanda
JOIN Produs_Meniu P ON D.id_produs = P.id_produs
WHERE Co.status = 'In procesare';