import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

 class FastFoodClient extends JFrame {

    // --- CONFIGURARE BAZA DE DATE ---
    // Modifica 'nume_baza_ta' cu numele real al bazei de date
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/restaurantFastFood ";
    private static final String USER = "postgres";
    private static final String PASS = "1234";

    // Componente GUI
    private JTextField txtId, txtNume, txtPrenume, txtTelefon, txtEmail;
    private JTable table;
    private DefaultTableModel tableModel;

    public FastFoodClient() {
        setTitle("Fast Food Manager - Client Java");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 1. Panel Formular (Sus)
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Date Client"));

        formPanel.add(new JLabel("ID (doar pt Update/Delete):"));
        txtId = new JTextField();
        formPanel.add(txtId);

        formPanel.add(new JLabel("Nume:"));
        txtNume = new JTextField();
        formPanel.add(txtNume);

        formPanel.add(new JLabel("Prenume:"));
        txtPrenume = new JTextField();
        formPanel.add(txtPrenume);

        formPanel.add(new JLabel("Telefon:"));
        txtTelefon = new JTextField();
        formPanel.add(txtTelefon);

        formPanel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        formPanel.add(txtEmail);

        add(formPanel, BorderLayout.NORTH);

        // 2. Tabel Rezultate (Centru)
        String[] columns = {"ID", "Nume", "Prenume", "Telefon", "Email"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 3. Panel Butoane (Jos)
        JPanel buttonPanel = new JPanel();

        JButton btnAdd = new JButton("Adauga (Insert)");
        JButton btnUpdate = new JButton("Update Telefon");
        JButton btnDelete = new JButton("Sterge (Delete)");
        JButton btnSearch = new JButton("Cauta (Search)");
        JButton btnRefresh = new JButton("Afiseaza Tot");

        // Culori pentru aspect
        btnAdd.setBackground(new Color(200, 255, 200));
        btnDelete.setBackground(new Color(255, 200, 200));
        btnSearch.setBackground(new Color(200, 200, 255));

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnSearch);
        buttonPanel.add(btnRefresh);

        add(buttonPanel, BorderLayout.SOUTH);

        // --- EVENIMENTE BUTOANE (Logica Aplicatiei) ---

        // A. INSERT
        btnAdd.addActionListener(e -> adaugaClient());

        // A. UPDATE
        btnUpdate.addActionListener(e -> updateClient());

        // A. DELETE
        btnDelete.addActionListener(e -> stergeClient());

        // B. CAUTARE
        btnSearch.addActionListener(e -> cautaClient());

        // RESET
        btnRefresh.addActionListener(e -> incarcaTabel("SELECT * FROM Client ORDER BY id_client"));

        // Incarcare initiala
        incarcaTabel("SELECT * FROM Client ORDER BY id_client");
    }

    // --- METODE PENTRU BAZA DE DATE ---

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

    private void adaugaClient() {
        String sql = "INSERT INTO Client(nume, prenume, telefon, email) VALUES(?, ?, ?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtNume.getText());
            pstmt.setString(2, txtPrenume.getText());
            pstmt.setString(3, txtTelefon.getText());
            pstmt.setString(4, txtEmail.getText());

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Client adaugat cu succes!");
            curataCampuri();
            incarcaTabel("SELECT * FROM Client ORDER BY id_client");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare DB: " + e.getMessage());
        }
    }

    private void updateClient() {
        // Actualizam telefonul pe baza ID-ului
        if(txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introdu ID-ul pentru actualizare!");
            return;
        }
        String sql = "UPDATE Client SET telefon = ? WHERE id_client = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, txtTelefon.getText());
            pstmt.setInt(2, Integer.parseInt(txtId.getText()));

            int rows = pstmt.executeUpdate();
            if(rows > 0) {
                JOptionPane.showMessageDialog(this, "Telefon actualizat!");
                incarcaTabel("SELECT * FROM Client ORDER BY id_client");
            } else {
                JOptionPane.showMessageDialog(this, "ID-ul nu exista!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare DB: " + e.getMessage());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID-ul trebuie sa fie numar!");
        }
    }

    private void stergeClient() {
        if(txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Introdu ID-ul pentru stergere!");
            return;
        }
        String sql = "DELETE FROM Client WHERE id_client = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, Integer.parseInt(txtId.getText()));

            int rows = pstmt.executeUpdate();
            if(rows > 0) {
                JOptionPane.showMessageDialog(this, "Client sters!");
                curataCampuri();
                incarcaTabel("SELECT * FROM Client ORDER BY id_client");
            } else {
                JOptionPane.showMessageDialog(this, "ID-ul nu exista!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare DB: " + e.getMessage());
        }
    }

    // B. IMPLEMENTARE CAUTARE CU CRITERII MULTIPLE
    private void cautaClient() {
        String nume = txtNume.getText();
        String telefon = txtTelefon.getText();

        StringBuilder query = new StringBuilder("SELECT * FROM Client WHERE 1=1");

        if (!nume.isEmpty()) {
            query.append(" AND nume ILIKE ?"); // ILIKE = case insensitive in Postgres
        }
        if (!telefon.isEmpty()) {
            query.append(" AND telefon LIKE ?");
        }

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(query.toString())) {

            int paramIndex = 1;
            if (!nume.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + nume + "%");
            }
            if (!telefon.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + telefon + "%");
            }

            ResultSet rs = pstmt.executeQuery();
            populeazaModel(rs);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Eroare Cautare: " + e.getMessage());
        }
    }

    private void incarcaTabel(String sql) {
        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            populeazaModel(rs);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void populeazaModel(ResultSet rs) throws SQLException {
        tableModel.setRowCount(0); // Goleste tabelul
        while (rs.next()) {
            Object[] row = {
                    rs.getInt("id_client"),
                    rs.getString("nume"),
                    rs.getString("prenume"),
                    rs.getString("telefon"),
                    rs.getString("email")
            };
            tableModel.addRow(row);
        }
    }

    private void curataCampuri() {
        txtId.setText("");
        txtNume.setText("");
        txtPrenume.setText("");
        txtTelefon.setText("");
        txtEmail.setText("");
    }

    public static void main(String[] args) {
        // Lansare aplicatie
        SwingUtilities.invokeLater(() -> {
            new FastFoodClient().setVisible(true);
        });
    }
}