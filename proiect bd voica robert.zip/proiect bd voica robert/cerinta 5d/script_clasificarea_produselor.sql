SELECT 
    denumire_produs,
    pret,
    -- CASE Expression pentru categorisire
    CASE 
        WHEN pret < 10 THEN 'Produs Ieftin'
        WHEN pret BETWEEN 10 AND 20 THEN 'Produs Standard'
        ELSE 'Produs Premium'
    END AS Categorie_Pret
FROM Produs_Meniu
ORDER BY pret DESC;