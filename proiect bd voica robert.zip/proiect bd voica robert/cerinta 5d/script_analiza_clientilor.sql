SELECT 
    -- 1. String: Concatenare si UPPER pentru nume complet
    UPPER(C.nume) || ' ' || C.prenume AS Nume_Complet,
    
    -- 2. String: Extragerea initialei prenumelui
    SUBSTRING(C.prenume FROM 1 FOR 1) || '.' AS Initiala,
    
    -- 3. Date: Formatarea datei intr-un format citibil (zi-luna-an)
    TO_CHAR(Co.data_ora, 'DD-MM-YYYY') AS Data_Formatata,
    
    -- 4. Date: Extragerea orei pentru a vedea cand e aglomerat
    EXTRACT(HOUR FROM Co.data_ora) AS Ora_Comenzii
FROM Client C
JOIN Comanda Co ON C.id_client = Co.id_client;