SELECT 
    C.nume, 
    C.prenume, 
    SUM(P.suma) AS Total_Cheltuit
FROM Client C
JOIN Comanda Co ON C.id_client = Co.id_client
JOIN Plata P ON Co.id_comanda = P.id_comanda
GROUP BY C.id_client, C.nume, C.prenume
HAVING SUM(P.suma) > 50;