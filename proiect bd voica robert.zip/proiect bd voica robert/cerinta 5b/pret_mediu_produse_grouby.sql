SELECT 
    C.denumire AS Categorie,
    ROUND(AVG(P.pret), 2) AS Pret_Mediu
FROM Produs_Meniu P
JOIN Categorie C ON P.id_categorie = C.id_categorie
GROUP BY C.denumire;