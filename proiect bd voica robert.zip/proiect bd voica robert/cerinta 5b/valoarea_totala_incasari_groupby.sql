SELECT 
    metoda_plata, 
    SUM(suma) AS Total_Incasari,
    COUNT(id_plata) AS Numar_Tranzactii
FROM Plata
WHERE metoda_plata IS NOT NULL
GROUP BY metoda_plata;