SELECT 
    A.nume, 
    A.prenume, 
    COUNT(Co.id_comanda) AS Nr_Comenzi_Procesate
FROM Angajat A
JOIN Comanda Co ON A.id_angajat = Co.id_angajat
GROUP BY A.id_angajat, A.nume, A.prenume
ORDER BY Nr_Comenzi_Procesate DESC;